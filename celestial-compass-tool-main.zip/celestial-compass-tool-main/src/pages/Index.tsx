import StarField from "@/components/StarField";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import NatalChartSection from "@/components/NatalChartSection";
import AiAstrologerSection from "@/components/AiAstrologerSection";
import AstroCalendarSection from "@/components/AstroCalendarSection";
import PricingSection from "@/components/PricingSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import FooterSection from "@/components/FooterSection";

const Index = () => {
  return (
    <div className="relative min-h-screen bg-background overflow-x-hidden">
      <StarField />
      <div className="relative z-10">
        <Header />
        <HeroSection />
        <NatalChartSection />
        <AiAstrologerSection />
        <AstroCalendarSection />
        <PricingSection />
        <TestimonialsSection />
        <FooterSection />
      </div>
    </div>
  );
};

export default Index;
