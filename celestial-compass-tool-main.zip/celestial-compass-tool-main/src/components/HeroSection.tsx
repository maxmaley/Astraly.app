import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const CHART_TYPES = [
  { value: "natal", label: "Натальная карта" },
  { value: "synastry", label: "Синастрия (совместимость)" },
  { value: "solar", label: "Соляр (год вперёд)" },
  { value: "transit", label: "Транзиты (сейчас)" },
  { value: "progressed", label: "Прогрессии" },
];

const TIMEZONES = [
  { value: "Europe/Moscow", label: "Москва (UTC+3)" },
  { value: "Europe/Kaliningrad", label: "Калининград (UTC+2)" },
  { value: "Europe/Samara", label: "Самара (UTC+4)" },
  { value: "Asia/Yekaterinburg", label: "Екатеринбург (UTC+5)" },
  { value: "Asia/Omsk", label: "Омск (UTC+6)" },
  { value: "Asia/Krasnoyarsk", label: "Красноярск (UTC+7)" },
  { value: "Asia/Irkutsk", label: "Иркутск (UTC+8)" },
  { value: "Asia/Yakutsk", label: "Якутск (UTC+9)" },
  { value: "Asia/Vladivostok", label: "Владивосток (UTC+10)" },
  { value: "Asia/Magadan", label: "Магадан (UTC+11)" },
  { value: "Asia/Kamchatka", label: "Камчатка (UTC+12)" },
  { value: "Europe/Kiev", label: "Киев (UTC+2)" },
  { value: "Europe/Minsk", label: "Минск (UTC+3)" },
  { value: "Asia/Almaty", label: "Алматы (UTC+6)" },
  { value: "Asia/Tashkent", label: "Ташкент (UTC+5)" },
];

const HeroSection = () => {
  const [name, setName] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [birthTime, setBirthTime] = useState("");
  const [timezone, setTimezone] = useState("");
  const [city, setCity] = useState("");
  const [chartType, setChartType] = useState("natal");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log({ name, birthDate, birthTime, timezone, city, chartType });
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Spline 3D Background */}
      <div className="absolute inset-0 z-0">
        {/* @ts-ignore */}
        <spline-viewer
          url="https://prod.spline.design/gaGR4Bwqmx43I-dv/scene.splinecode"
          style={{ width: "100%", height: "100%", position: "absolute", inset: 0 }}
        />
        <div className="absolute inset-0 bg-background/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-3xl mx-auto w-full">
        <h1
          className="font-display text-3xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4 animate-fade-in-up"
          style={{
            background: "linear-gradient(135deg, #ffffff, #c9a0ff, #FFD700)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}
        >
          Звёзды знали о тебе всё.
          <br />
          Ещё до твоего рождения.
        </h1>

        <p
          className="text-base md:text-lg text-muted-foreground mb-8 max-w-2xl mx-auto animate-fade-in-up font-body italic"
          style={{ animationDelay: "0.2s" }}
        >
          Введи свои данные — и узнай, что говорят звёзды о твоей судьбе
        </p>

        {/* Birth Data Form */}
        <form
          onSubmit={handleSubmit}
          className="animate-fade-in-up glass-card p-6 md:p-8 rounded-2xl mx-auto max-w-2xl space-y-4"
          style={{ animationDelay: "0.3s" }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              placeholder="Твоё имя"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-background/40 border-primary/20 placeholder:text-muted-foreground/60 focus:border-primary/60 h-12"
            />
            <Input
              placeholder="Город рождения"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="bg-background/40 border-primary/20 placeholder:text-muted-foreground/60 focus:border-primary/60 h-12"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <label className="absolute -top-2.5 left-3 text-xs text-muted-foreground/80 bg-background/60 px-1 rounded">
                Дата рождения
              </label>
              <Input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="bg-background/40 border-primary/20 text-foreground focus:border-primary/60 h-12 [color-scheme:dark]"
              />
            </div>
            <div className="relative">
              <label className="absolute -top-2.5 left-3 text-xs text-muted-foreground/80 bg-background/60 px-1 rounded">
                Время рождения
              </label>
              <Input
                type="time"
                value={birthTime}
                onChange={(e) => setBirthTime(e.target.value)}
                className="bg-background/40 border-primary/20 text-foreground focus:border-primary/60 h-12 [color-scheme:dark]"
              />
            </div>
            <Select value={timezone} onValueChange={setTimezone}>
              <SelectTrigger className="bg-background/40 border-primary/20 text-foreground focus:border-primary/60 h-12">
                <SelectValue placeholder="Часовой пояс" />
              </SelectTrigger>
              <SelectContent className="bg-background border-primary/20">
                {TIMEZONES.map((tz) => (
                  <SelectItem key={tz.value} value={tz.value}>
                    {tz.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Select value={chartType} onValueChange={setChartType}>
            <SelectTrigger className="bg-background/40 border-primary/20 text-foreground focus:border-primary/60 h-12">
              <SelectValue placeholder="Тип расчёта" />
            </SelectTrigger>
            <SelectContent className="bg-background border-primary/20">
              {CHART_TYPES.map((ct) => (
                <SelectItem key={ct.value} value={ct.value}>
                  {ct.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <button type="submit" className="glow-button text-lg md:text-xl font-display w-full">
            Узнать свою судьбу бесплатно →
          </button>

          <p className="text-xs text-muted-foreground/60">
            Уже <span className="text-glow-soft font-semibold">12 847</span> женщин открыли свою карту сегодня
          </p>
        </form>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-10" />
    </section>
  );
};

export default HeroSection;
