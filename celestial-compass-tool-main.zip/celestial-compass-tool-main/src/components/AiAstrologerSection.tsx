import { useEffect, useState } from "react";

const chatMessages = [
  { role: "user" as const, text: "Почему у меня не складывается с Козерогами?" },
  { role: "ai" as const, text: "💫 Твоя Венера в Рыбах создаёт особую чувствительность в отношениях. Козероги — земной знак, им сложно понять твою глубину чувств. Но это не приговор — расскажу подробнее..." },
  { role: "user" as const, text: "Стоит ли мне менять работу в этом месяце?" },
  { role: "ai" as const, text: "🔮 Юпитер сейчас транзитирует твой 10-й дом карьеры. Это редкое окно возможностей, которое открывается раз в 12 лет. Действуй до конца месяца!" },
];

const AiAstrologerSection = () => {
  const [visibleMessages, setVisibleMessages] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setVisibleMessages((v) => {
        if (v >= chatMessages.length) return v;
        return v + 1;
      });
    }, 800);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative py-24 md:py-32 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading mb-4">Астролог, который всегда с тобой</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Задай любой вопрос — о любви, карьере, отношениях. Он знает твою карту и помнит каждый разговор.
          </p>
        </div>

        {/* Chat Mockup */}
        <div className="max-w-lg mx-auto mb-12">
          <div className="glass-card-glow p-6 rounded-3xl">
            {/* Chat header */}
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-border/30">
              <div className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, hsl(262, 100%, 59%), hsl(280, 80%, 50%))" }}
              >
                <span className="text-lg">🔮</span>
              </div>
              <div>
                <p className="font-semibold text-foreground text-sm">AI Астролог</p>
                <p className="text-xs text-muted-foreground">Онлайн • Знает твою карту</p>
              </div>
            </div>

            {/* Messages */}
            <div className="space-y-4 min-h-[280px]">
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} ${
                    i < visibleMessages ? "animate-chat-appear" : "opacity-0"
                  }`}
                  style={{ animationDelay: `${i * 0.15}s` }}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-primary/20 text-foreground rounded-br-sm"
                        : "bg-muted/50 text-foreground rounded-bl-sm"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Input mockup */}
            <div className="mt-4 flex items-center gap-2 rounded-full border border-border/30 px-4 py-3 bg-muted/20">
              <span className="text-muted-foreground text-sm flex-1">Задай вопрос звёздам...</span>
              <div className="w-8 h-8 rounded-full bg-primary/30 flex items-center justify-center">
                <span className="text-xs">✨</span>
              </div>
            </div>
          </div>
        </div>

        <p className="fomo-text text-center text-lg mb-8">
          ⏰ Пока ты сомневаешься — Меркурий уходит в ретро через 3 дня
        </p>

        <div className="text-center">
          <a href="#hero" className="glow-button inline-block text-base md:text-lg font-display">
            Задать вопрос AI астрологу →
          </a>
        </div>
      </div>
    </section>
  );
};

export default AiAstrologerSection;
