const plans = [
  {
    name: "Бесплатно",
    price: "0",
    period: "",
    popular: false,
    features: [
      "Натальная карта",
      "3 сообщения с AI-астрологом",
    ],
    cta: "Начать бесплатно",
    ctaStyle: "outline" as const,
  },
  {
    name: "Звезда",
    price: "2.99",
    period: "/месяц",
    popular: false,
    features: [
      "Натальная карта для тебя и близких",
      "Безлимитный чат с AI-астрологом",
    ],
    cta: "Попробовать 3 дня бесплатно",
    ctaStyle: "outline" as const,
  },
  {
    name: "Космос",
    price: "3.99",
    period: "/месяц",
    popular: true,
    features: [
      "Всё из плана «Звезда»",
      "Ежедневный персональный гороскоп",
      "Уведомления на почту + Telegram",
    ],
    cta: "Попробовать 3 дня бесплатно",
    ctaStyle: "primary" as const,
  },
  {
    name: "Вселенная",
    price: "4.99",
    period: "/месяц",
    popular: false,
    features: [
      "Всё из плана «Космос»",
      "Персональный астро-календарь",
      "Синхронизация с Google Calendar",
    ],
    cta: "Попробовать 3 дня бесплатно",
    ctaStyle: "outline" as const,
  },
];

const PricingSection = () => {
  return (
    <section className="relative py-24 md:py-32 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading mb-4">Выбери свой путь к звёздам</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative ${plan.popular ? "glass-card-popular" : "glass-card-glow"} p-6 rounded-2xl flex flex-col ${
                plan.popular ? "lg:-mt-4 lg:mb-[-16px]" : ""
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-semibold"
                  style={{
                    background: "linear-gradient(135deg, hsl(262, 100%, 59%), hsl(51, 100%, 50%))",
                    color: "hsl(240, 53%, 11%)",
                  }}
                >
                  ⭐ Самый популярный
                </div>
              )}

              <h3 className="font-display text-xl font-semibold text-foreground mt-2 mb-4">{plan.name}</h3>

              <div className="mb-6">
                <span className="text-4xl font-bold text-foreground">
                  {plan.price === "0" ? "Бесплатно" : `$${plan.price}`}
                </span>
                {plan.period && (
                  <span className="text-muted-foreground text-sm">{plan.period}</span>
                )}
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="text-glow-soft mt-0.5 shrink-0">✦</span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <button
                className={
                  plan.ctaStyle === "primary"
                    ? "glow-button w-full text-sm"
                    : "glow-button-outline w-full text-sm"
                }
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        <p className="text-center text-sm text-muted-foreground mt-10">
          Отмена в любой момент • Без скрытых платежей • 3 дня бесплатно
        </p>
      </div>
    </section>
  );
};

export default PricingSection;
