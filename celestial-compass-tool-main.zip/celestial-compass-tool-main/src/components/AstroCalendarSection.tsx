const calendarEvents = [
  { icon: "⚠️", text: "Меркурий ретро — избегай важных решений", color: "hsl(0, 84%, 60%)" },
  { icon: "✨", text: "Удачный день для переговоров", color: "hsl(262, 100%, 59%)" },
  { icon: "❤️", text: "Венера активирует твою 7-ю сферу — идеально для свидания", color: "hsl(340, 80%, 60%)" },
  { icon: "💰", text: "Благоприятный период для финансов", color: "hsl(51, 100%, 50%)" },
];

const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

const AstroCalendarSection = () => {
  return (
    <section className="relative py-24 md:py-32 overflow-hidden cosmic-gradient-bg">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading mb-4">Живи в ритме звёзд</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Персональный астро-календарь синхронизируется с Google Calendar. Ты всегда знаешь когда действовать, а когда ждать.
          </p>
        </div>

        {/* Calendar Mockup */}
        <div className="max-w-2xl mx-auto">
          <div className="glass-card-glow p-6 md:p-8 rounded-3xl">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-xl font-semibold text-foreground">Март 2026</h3>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-primary/10 border border-primary/20">
                  <span>📅</span> Синхронизирован с Google
                </span>
              </div>
            </div>

            {/* Days header */}
            <div className="grid grid-cols-7 gap-1 mb-2">
              {days.map((d) => (
                <div key={d} className="text-center text-xs text-muted-foreground py-2 font-medium">{d}</div>
              ))}
            </div>

            {/* Calendar grid */}
            <div className="grid grid-cols-7 gap-1 mb-8">
              {Array.from({ length: 35 }, (_, i) => {
                const day = i - 1;
                const isValid = day >= 1 && day <= 31;
                const hasEvent = [5, 12, 18, 25].includes(day);
                return (
                  <div
                    key={i}
                    className={`aspect-square flex items-center justify-center text-sm rounded-lg transition-all ${
                      isValid
                        ? hasEvent
                          ? "bg-primary/15 text-foreground border border-primary/20"
                          : "text-muted-foreground hover:bg-muted/30"
                        : ""
                    }`}
                  >
                    {isValid ? (
                      <span>{day}</span>
                    ) : null}
                  </div>
                );
              })}
            </div>

            {/* Events */}
            <div className="space-y-3">
              {calendarEvents.map((event, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 p-3 rounded-xl bg-muted/20 border border-border/20 transition-all hover:bg-muted/30"
                >
                  <span className="text-lg mt-0.5">{event.icon}</span>
                  <p className="text-sm text-foreground leading-relaxed">{event.text}</p>
                  <div
                    className="w-2 h-2 rounded-full mt-1.5 ml-auto shrink-0"
                    style={{ backgroundColor: event.color }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="text-center mt-10">
          <a href="#hero" className="glow-button inline-block text-base md:text-lg font-display">
            Получить свой астро-календарь →
          </a>
        </div>
      </div>
    </section>
  );
};

export default AstroCalendarSection;
