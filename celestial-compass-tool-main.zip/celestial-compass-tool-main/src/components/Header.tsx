import { Button } from "@/components/ui/button";

const Header = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-background/30 border-b border-border/10">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <a href="/" className="font-display text-xl font-bold text-foreground tracking-tight">
          Astraly
          <span className="text-primary">.app</span>
        </a>

        <Button
          variant="outline"
          size="sm"
          className="border-primary/30 text-foreground hover:bg-primary/10 hover:border-primary/60 transition-all"
        >
          Войти
        </Button>
      </div>
    </header>
  );
};

export default Header;
