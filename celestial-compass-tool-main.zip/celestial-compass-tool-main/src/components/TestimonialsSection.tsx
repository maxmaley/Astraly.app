const testimonials = [
  {
    name: "Анастасия",
    sign: "♏ Скорпион",
    text: "Я скептически относилась к астрологии, но когда прочитала свою карту — мурашки. Всё про меня.",
    avatar: "А",
  },
  {
    name: "Мария",
    sign: "♋ Рак",
    text: "Астро-календарь изменил мою жизнь. Теперь я знаю когда проводить важные встречи.",
    avatar: "М",
  },
  {
    name: "Екатерина",
    sign: "♓ Рыбы",
    text: "Наконец-то поняла почему у меня не получалось с Овнами 😂 Венера всему виной",
    avatar: "Е",
  },
];

const TestimonialsSection = () => {
  return (
    <section className="relative py-24 md:py-32 overflow-hidden cosmic-gradient-bg">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading mb-4">Что говорят наши пользователи</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((t, i) => (
            <div key={i} className="glass-card-glow p-6 rounded-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-11 h-11 rounded-full flex items-center justify-center font-display font-bold text-lg"
                  style={{
                    background: "linear-gradient(135deg, hsl(262, 100%, 59%), hsl(280, 80%, 50%))",
                  }}
                >
                  {t.avatar}
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">{t.name}</p>
                  <p className="text-xs text-glow-soft">{t.sign}</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed italic">"{t.text}"</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a href="#hero" className="glow-button inline-block text-base md:text-lg font-display">
            Попробовать бесплатно →
          </a>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
