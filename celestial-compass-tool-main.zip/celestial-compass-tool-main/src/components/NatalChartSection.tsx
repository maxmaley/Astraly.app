import { useEffect, useState } from "react";

const zodiacSymbols = ["♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"];

const NatalChartSection = () => {
  const [rotation, setRotation] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setRotation((r) => r + 0.3);
    }, 50);

    const timer = setTimeout(() => setIsVisible(true), 300);
    return () => {
      clearInterval(interval);
      clearTimeout(timer);
    };
  }, []);

  return (
    <section className="relative py-24 md:py-32 overflow-hidden cosmic-gradient-bg">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading mb-4">Твоя уникальная карта звёзд</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Каждый человек рождается с картой, которая описывает его характер, таланты, любовь и судьбу. Большинство так и не узнают свою.
          </p>
        </div>

        {/* Zodiac Wheel */}
        <div className="flex justify-center mb-12">
          <div className="relative w-72 h-72 md:w-96 md:h-96">
            {/* Outer ring */}
            <div
              className="absolute inset-0 rounded-full border-2 border-primary/30"
              style={{ transform: `rotate(${rotation}deg)` }}
            >
              {zodiacSymbols.map((symbol, i) => {
                const angle = (i * 30 - 90) * (Math.PI / 180);
                const radius = 45;
                const x = 50 + radius * Math.cos(angle);
                const y = 50 + radius * Math.sin(angle);
                return (
                  <span
                    key={i}
                    className="absolute text-xl md:text-2xl transition-opacity duration-1000"
                    style={{
                      left: `${x}%`,
                      top: `${y}%`,
                      transform: `translate(-50%, -50%) rotate(${-rotation}deg)`,
                      opacity: isVisible ? 1 : 0,
                      transitionDelay: `${i * 100}ms`,
                      textShadow: "0 0 10px hsla(262, 100%, 59%, 0.5)",
                    }}
                  >
                    {symbol}
                  </span>
                );
              })}
            </div>

            {/* Inner ring */}
            <div
              className="absolute inset-8 md:inset-12 rounded-full border border-glow-soft/20"
              style={{ transform: `rotate(${-rotation * 0.5}deg)` }}
            />

            {/* Center */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-full flex items-center justify-center"
                style={{
                  background: "radial-gradient(circle, hsla(262, 100%, 59%, 0.3), transparent)",
                  boxShadow: "0 0 40px hsla(262, 100%, 59%, 0.2)",
                }}
              >
                <span className="text-3xl md:text-4xl">✨</span>
              </div>
            </div>

            {/* Connection lines */}
            <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 100 100">
              <line x1="20" y1="30" x2="80" y2="70" stroke="hsl(262, 100%, 59%)" strokeWidth="0.3" />
              <line x1="50" y1="5" x2="30" y2="85" stroke="hsl(268, 100%, 81%)" strokeWidth="0.3" />
              <line x1="15" y1="60" x2="85" y2="40" stroke="hsl(262, 100%, 59%)" strokeWidth="0.3" />
              <line x1="35" y1="15" x2="70" y2="90" stroke="hsl(268, 100%, 81%)" strokeWidth="0.3" />
            </svg>
          </div>
        </div>

        <p className="fomo-text text-center text-lg mb-8">
          ⚡ Не знать свою карту — всё равно что жить вслепую
        </p>

        <div className="text-center">
          <a href="#hero" className="glow-button inline-block text-base md:text-lg font-display">
            Узнать свою карту бесплатно →
          </a>
        </div>
      </div>
    </section>
  );
};

export default NatalChartSection;
